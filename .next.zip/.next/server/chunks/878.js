"use strict";
exports.id = 878;
exports.ids = [878];
exports.modules = {

/***/ 2878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_logo_dodas_logo_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6380);
/* harmony import */ var _SideNav_SideNav__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7567);







const Header = ()=>{
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [sidebarShow, setSidebarShow] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-4 w-full z-50 overflow-hidden relative  text-white items-center py-3 flex justify-around ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center  w-full  gap-10 lg:gap-x-24",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-24",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        src: _assets_logo_dodas_logo_png__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                        className: "w-full",
                                        alt: "BHM Logo"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "relative md:block hidden mr-0 lg:mr-0 md:mr-60",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "py-2 lg:py-3 text-gray-900 text-sm px-5 border-[#000000]/10  rounded-2xl w-full xl:w-[347px]",
                                        placeholder: "Search here"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: "w-4 hover:cursor-pointer lg:w-6 h-4 lg:h-6 absolute top-1/4 text-[#000000]/70 right-2 lg:right-4 ",
                                            width: "25",
                                            height: "25",
                                            viewBox: "0 0 25 25",
                                            fill: "none",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                d: "M21.5355 19.4974L18.1184 16.2326C19.2209 14.8867 19.8191 13.2247 19.8169 11.5137C19.8169 9.98996 19.3453 8.5004 18.4619 7.23343C17.5784 5.96646 16.3227 4.97897 14.8535 4.39585C13.3843 3.81273 11.7677 3.66015 10.208 3.95743C8.64837 4.2547 7.21573 4.98847 6.09128 6.06594C4.96682 7.14341 4.20106 8.5162 3.89082 10.0107C3.58059 11.5052 3.73981 13.0543 4.34836 14.4621C4.95691 15.8698 5.98745 17.0731 7.30967 17.9197C8.63189 18.7662 10.1864 19.2181 11.7766 19.2181C13.5622 19.2202 15.2967 18.647 16.7013 17.5905L20.1084 20.8649C20.2018 20.9551 20.3129 21.0268 20.4354 21.0757C20.5579 21.1246 20.6893 21.1497 20.8219 21.1497C20.9546 21.1497 21.086 21.1246 21.2084 21.0757C21.3309 21.0268 21.4421 20.9551 21.5355 20.8649C21.6297 20.7754 21.7045 20.6688 21.7555 20.5515C21.8065 20.4341 21.8328 20.3083 21.8328 20.1811C21.8328 20.054 21.8065 19.9281 21.7555 19.8108C21.7045 19.6934 21.6297 19.5869 21.5355 19.4974ZM5.7464 11.5137C5.7464 10.3709 6.10007 9.25374 6.76268 8.30351C7.42528 7.35328 8.36707 6.61266 9.46895 6.17532C10.5708 5.73798 11.7833 5.62355 12.953 5.8465C14.1228 6.06946 15.1973 6.61979 16.0406 7.42789C16.884 8.23599 17.4583 9.26558 17.691 10.3865C17.9236 11.5073 17.8042 12.6691 17.3478 13.725C16.8914 14.7808 16.1185 15.6833 15.1268 16.3182C14.1352 16.9531 12.9693 17.292 11.7766 17.292C10.1773 17.292 8.64349 16.6832 7.51261 15.5996C6.38173 14.5159 5.7464 13.0462 5.7464 11.5137Z",
                                                fill: "#1E1E1E"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "flex gap-10 items-center justify-around pl-32",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/",
                                    className: `flex  text-lg hover:cursor-pointer text-[#1E1E1E]/50 hover:text-black items-center w-full  pl-3 pr-4 font-medium rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0  md:p-0 md:w-auto ${router.pathname === "/discover" ? "text-black underline" : "text-[#1E1E1E]/50"}`,
                                    children: "Discover"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/calender",
                                    className: "flex  text-lg hover:cursor-pointer text-[#1E1E1E]/50 hover:text-black items-center w-full  pl-3 pr-4 font-medium rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0  md:p-0 md:w-auto",
                                    children: "Calendar"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/rewards",
                                    className: `flex  text-lg hover:cursor-pointer text-[#1E1E1E]/50 hover:text-black items-center w-full  pl-3 pr-4 font-medium rounded hover:bg-gray-100 md:hover:bg-transparent md:border-0  md:p-0 md:w-auto ${router.pathname === "/rewards" ? "text-black underline" : "text-[#1E1E1E]/50"}`,
                                    children: "Rewards"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: `md:flex lg:flex  w-full left-0 p-3 py-4 gap-4 lg:z-50 items-center  font-semibold  text-black text-center md:justify-center lg:justify-end lg:static   duration-300 ease-linear absolute ${open ? "top-14" : "top-[-450px]"}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/auth/signup ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "button",
                                        className: "text-black border border-black  focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2  ",
                                        children: "Sign Up"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/auth/signin",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        type: "button",
                                        className: "text-white bg-black  focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 ",
                                        children: "Sign In"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                    width: "29",
                                    height: "21",
                                    viewBox: "0 0 29 21",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M1.8252 10.4768H27.3252",
                                            stroke: "black",
                                            strokeWidth: "2.83333",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M1.8252 1.97681H27.3252",
                                            stroke: "black",
                                            strokeWidth: "2.83333",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                            d: "M1.8252 18.9768H27.3252",
                                            stroke: "black",
                                            strokeWidth: "2.83333",
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>setOpen(!open),
                        className: "h-6 ml-2  text-slate-900 w-6 lg:hidden",
                        children: open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AiOutlineCloseCircle, {
                            className: "w-6 h-6"
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                            width: "25",
                            height: "24",
                            viewBox: "0 0 25 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M3.23438 12H21.2344",
                                    stroke: "black",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M3.23438 6H21.2344",
                                    stroke: "black",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    d: "M3.23438 18H21.2344",
                                    stroke: "black",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SideNav_SideNav__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                sidebarShow: sidebarShow,
                setSidebarShow: setSidebarShow
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);


/***/ })

};
;